<template>
    <b-container class="bv-example-row mt-3">
      <router-view></router-view>
    </b-container>
  </template>
  <script>
  export default {
    name: "AppUser",
  };
  </script>
  <style scoped>
  </style>
  