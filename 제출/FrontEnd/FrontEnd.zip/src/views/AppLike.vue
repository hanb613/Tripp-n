<template>
  <b-container class="bv-example-row mt-3">
    <h3><b-icon icon="bookmark-star"></b-icon> 관심 목록</h3>
  </b-container>
</template>
<script>
export default {
  name: "AppLike",
};
</script>
<style scoped></style>
